package com.manip.myapplication;

import android.graphics.Color;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private LinearLayout mainLL;
    private DrawLL drawLL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initGraphique();
    }

    private void initGraphique() {
        mainLL=findViewById(R.id.mainLL);
        drawLL=new DrawLL(this);
        drawLL.setBackgroundColor(Color.CYAN);
        drawLL.setMinimumWidth(200);
        drawLL.setMinimumHeight(1000);
        drawLL.setVisibility(View.VISIBLE);
        mainLL.addView(drawLL);
        drawLL.invalidate();
        ajouterEcouteurs();
    }

    private void ajouterEcouteurs() {
       
    }


}