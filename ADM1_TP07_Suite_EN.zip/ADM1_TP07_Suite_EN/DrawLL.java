package com.manip.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.SparseArray;
import android.widget.LinearLayout;

public class DrawLL extends LinearLayout {
    private Canvas canvas;
    private SparseArray<Point> tabPoint;
    public DrawLL(Context context) {
        super(context);
        tabPoint=new SparseArray<Point>();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.canvas=canvas;
        for(int i=0;i<tabPoint.size();i++) {
            Point p=tabPoint.get(i);
            dessinerCercle(p.x, p.y, 5);
        }
    }


    private void dessinerCercle(float cx, float cy,float r){
        Paint paint=new Paint();
        paint.setStyle(Paint.Style.FILL);
        paint.setStrokeWidth(r);
        paint.setColor(Color.BLUE);
        if(canvas!=null) {
            canvas.drawCircle(cx, cy, r, paint);
        }
    }
    public void ajouterPoint(Point p){
        tabPoint.put(tabPoint.size(),p);
        invalidate();
    }
}
