package addition.com.projet;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    private static final int ACTION_AJOUT = 1;
    private Button btnA;
    private Button btnST;
    private ListView lstP;
    private ArrayAdapter<Pays> adpP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        btnA=(Button)findViewById(R.id.btnA);
        btnST=(Button)findViewById(R.id.btnST);
        lstP=(ListView)findViewById(R.id.lstP);
        
    }

   
}
