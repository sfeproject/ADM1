package addition.com.projet;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class Pays {

   private String nom;
   private String capitale;
   private int nbVille;

    public Pays(String nom, String capitale, int nbVille) {
        this.nom = nom;
        this.capitale = capitale;
        this.nbVille = nbVille;
    }

    public String getNom() {
        return nom;
    }

    public String getCapitale() {
        return capitale;
    }

    public int getNbVille() {
        return nbVille;
    }

    
}
