package addition.com.projet;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Ajout extends AppCompatActivity {
    private EditText edN;
    private EditText edC;
    private EditText edNb;
    private Button btnV;
    private Button btnA;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ajout);
        init();
    }

    private void init() {
        edN=(EditText)findViewById(R.id.edN);
        edC=(EditText)findViewById(R.id.edC);
        edNb=(EditText)findViewById(R.id.edNb);
        btnV=(Button)findViewById(R.id.btnV);
        btnA=(Button)findViewById(R.id.btnA);
       
    }

    
}
