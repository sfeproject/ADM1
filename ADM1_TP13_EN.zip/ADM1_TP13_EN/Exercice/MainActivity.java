package radio.com.paramradio;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText edF;
    private Spinner spT;
    private SeekBar seekV;
    private RadioGroup rdgSt;
    private Button btnEn;
    private Button btnAff;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        edF =  findViewById(R.id.edF);
        spT =  findViewById(R.id.spT);
        seekV=findViewById(R.id.seekV);
        rdgSt = findViewById(R.id.rdgSt);
        btnEn =  findViewById(R.id.btnEn);
        btnAff =  findViewById(R.id.btnAff);
        
    }

}
