package projet.com.prixvignette;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText edM;
    private Spinner spT;
    private SeekBar seekP;
    private RadioGroup rdgC;
    private RadioButton rdE;
    private Button btnA;
    private Button btnE;
    private Button btnV;
    private ListView lstA;
   

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
       
    }

    private void ajouterEcouteurs() {
      
    }


    private void ajouter() {
        
        
    }

    private void effacer() {
        
    }

    private void vider() {
       
    }

    private void afficher(int position) {
        
    }
}
