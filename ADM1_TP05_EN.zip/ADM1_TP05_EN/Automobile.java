package projet.com.prixvignette;

public class Automobile {
    private static final int[][] TARIF_PHYSIQUE={{60,210,385},{120,270,445}};
    private static final int[][] TARIF_MORALE={{120,270,445},{240,390,565}};
    private String matricule;
    private int type;   // 0 : Personne physique  1 : Personne morale
    private int puissance;
    private String carburent;


   

    public int getPrix() {
        int iP=0;
        int iC=0;
        iP=(puissance<=4)?0:1;
        if(carburent.equalsIgnoreCase("Essence"))
            iC=0;
        else if(carburent.equalsIgnoreCase("Diesel"))
            iC=1;
        else
            iC=2;
        if (type == 0)
            return TARIF_PHYSIQUE[iP][iC];
        else
            return TARIF_MORALE[iP][iC];
    }
   
}
