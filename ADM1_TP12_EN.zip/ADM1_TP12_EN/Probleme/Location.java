package com.location;

public class Location {
    private String personne;
    private String voiture;
    private int nbJours;

    public Location(String personne, String voiture, int nbJours) {
        this.personne = personne;
        this.voiture = voiture;
        this.nbJours = nbJours;
    }

    public String getPersonne() {
        return personne;
    }

    public String getVoiture() {
        return voiture;
    }

    public int getNbJours() {
        return nbJours;
    }

    
}
