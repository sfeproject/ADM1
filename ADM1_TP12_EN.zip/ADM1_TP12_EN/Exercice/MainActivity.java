package com.tartil.alarme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText edT;
    private Spinner spS;
    private SeekBar seekV;
    private RadioGroup rdgR;
    private Button btnE;
    private Button btnA;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        edT = findViewById(R.id.edT);
        spS = findViewById(R.id.spS);
        seekV = findViewById(R.id.seekV);
        rdgR = findViewById(R.id.rdgR);
        btnE = findViewById(R.id.btnE);
        btnA = findViewById(R.id.btnA);
       
    }

   

}