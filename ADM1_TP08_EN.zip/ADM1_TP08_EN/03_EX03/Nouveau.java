package com.recup_resultat;

public class Nouveau extends Activity {
  private EditText edNom;
  private EditText edPrenom;
  private EditText edAge;
  private Button btnValider;
  private Button btnAnnuler;
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.nouveau);
    init();
  }
  private void init() {
    edNom = (EditText) findViewById(R.id.edNom);
    edPrenom = (EditText) findViewById(R.id.edPrenom);
    edAge = (EditText) findViewById(R.id.edAge);
    btnValider = (Button) findViewById(R.id.btnValider);
    btnAnnuler = (Button) findViewById(R.id.btnAnnuler);
    ajouterEcouteur();
  }
  private void ajouterEcouteur() {
   
  }

}

